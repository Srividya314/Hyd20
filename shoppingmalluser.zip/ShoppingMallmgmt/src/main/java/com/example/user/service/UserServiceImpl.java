package com.example.user.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.entity.User;
import com.example.user.repository.UserRepository;


@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository ur1;

    @Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return ur1.save(user);
	}


	@Override
	public List<User> fetchUserList() {
		// TODO Auto-generated method stub
		return ur1.findAll();
	}


	@Override
	public User fetchUsertById(Long id) {
		// TODO Auto-generated method stub
		return ur1.findById(id).get();
	}


	@Override
	public void deleteUserById(Long id) {
		// TODO Auto-generated method stub
		ur1.deleteById(id);
	}




	@Override
	public User updateUser(Long id, User user) {
		// TODO Auto-generated method stub
		 User userDB = ur1.findById(id).get();

	       if(Objects.nonNull(user.getName()) &&
	       !"".equalsIgnoreCase(user.getName())) {
	           userDB.setName(user.getName());
	       }

	       if(Objects.nonNull(user.getType()) &&
	               !"".equalsIgnoreCase(user.getType())) {
	           userDB.setType(user.getType());
	       }

	       if(Objects.nonNull(user.getPassword()) &&
	               !"".equalsIgnoreCase(user.getPassword())) {
	           userDB.setPassword(user.getPassword());
	       }

	       return ur1.save(userDB);
	}

	    
	  
}

	 

