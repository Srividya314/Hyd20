package com.example.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.user.entity.User;
import com.example.user.service.UserService;



@RestController
public class UserController {
	@Autowired
	UserService us1;
	 
	 @PostMapping("/users")
	 public User saveUser(@RequestBody User user) {
	 	
	 	return us1.saveUser(user);

}
	 @GetMapping("/users")
	    public List<User> fetchUserList() {
	        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
	        return us1.fetchUserList();
	    }
	    


	    @GetMapping("/users/{id}")
	    public User fetchUserById(@PathVariable("id") Long id)
	            {
	        return us1.fetchUsertById(id);
	    }
	    
	    @DeleteMapping("/users/{id}")
	    public String deleteUserById(@PathVariable("id") Long id) {
	        us1.deleteUserById(id);
	        return "User deleted Successfully!!";
	    }
	    @PutMapping("/users/{id}")
	    public User updateUser(@PathVariable("id") Long id,
	                                       @RequestBody User user) {
	        return us1.updateUser(id,user);
	    }
}
